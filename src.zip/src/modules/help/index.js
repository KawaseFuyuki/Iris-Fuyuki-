import { makeEmbed, YELLOW } from '../../utils.js';
import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';

const pages = [
  {
    title: '📖 Help — Module A: Reaction Roles',
    description: [
      '**Slash Commands (/ only)**',
      '`/reactionrole` — Add reaction role to a message by ID',
      '`/reactionrole-image` — Add reaction role based on image name in embed',
      '`/addrole` — Add a role to a user',
      '`/removerole` — Remove a role from a user',
      '`/temprole` — Give a temporary role (e.g. 10m, 2h, 1d)',
      '`/timer` — Set a recurring message timer',
      '`/rr-list` — List all reaction roles',
      '`/rr-remove` — Remove a reaction role by ID',
    ].join('\n')
  },
  {
    title: '🛡️ Help — Module B: Moderation',
    description: [
      '**Prefix Commands (&)**',
      '`&antilink enable/disable` — Toggle anti-link (GIFs allowed)',
      '`&antinuke enable/disable` — Toggle anti-nuke protection',
      '`&mute @user [duration] [reason]` — Mute a user',
      '`&unmute @user` — Unmute a user',
      '`&ban @user [reason]` — Ban a user',
      '`&unban <id>` — Unban a user by ID',
      '`&warn @user [reason]` — Warn a user',
      '`&warnings @user` — View warnings',
      '`&clearwarns @user` — Clear all warnings',
      '`&purge <1-150>` — Delete messages (max 150)',
      '`&lock` — Lock current channel',
      '`&unlock` — Unlock current channel',
      '`&blacklist <word>` — Add word to blacklist',
      '`&unblacklist <word>` — Remove word from blacklist',
      '`&blacklistlist` — List blacklisted words',
      '`&disable <cmd> [#channel]` — Disable a command in channel',
      '`&enable <cmd> [#channel]` — Re-enable a command',
      '`&logs #channel` — Set log channel',
      '`&snipe` — Show last deleted message',
    ].join('\n')
  },
  {
    title: '📊 Help — Module C: Info & Giveaways',
    description: [
      '**Prefix Commands (&)**',
      '`&av / &avatar [@user]` — Show avatar',
      '`&si / &serverinfo` — Server information',
      '`&ui / &userinfo [@user]` — User information',
      '`&mc / &membercount` — Member count',
      '`&i / &invites [@user]` — Show invites (joins/real/left/fake)',
      '`&ilb / &inviteleaderboard` — Invite leaderboard (paginated)',
      '`&ireset [@user]` — Reset your own invites',
      '`&ireset all` — Reset ALL invites (admin only)',
      '`&trigger add <word> <reply>` — Add trigger',
      '`&trigger add <word> reaction <emoji>` — Add reaction trigger',
      '`&trigger remove <id>` — Remove trigger',
      '`&trigger list` — List triggers',
      '',
      '**Giveaways (prefix & slash)**',
      '`&gs <dur> <winners> <prize>` — Start giveaway',
      '`&ge <id>` — End giveaway',
      '`&gr <id>` — Reroll giveaway',
      '`/giveaway start/end/reroll` — Slash equivalents',
    ].join('\n')
  },
  {
    title: '⚙️ Help — Module D: Server Setup',
    description: [
      '**Slash Commands (/ only)**',
      '`/welcome setup` — Setup welcome message',
      '  Options: channel, title, description, color, image',
      '  Variables in description: {user} {server} {count}',
      '`/welcome test` — Test welcome message',
      '`/welcome remove` — Remove welcome system',
      '',
      '`/ticket setup` — Setup ticket panel',
      '  Options: channel, title, description, category, role, emoji, color, image',
      '`/ticket addbutton` — Add extra button (max 3)',
      '`/ticket close` — Close current ticket',
      '',
      '`/embed` — Send a custom embed to a channel',
      '',
      '**Reaction Role Panel**',
      '`/reactionrole` — Add reaction role by message ID',
    ].join('\n')
  },
  {
    title: '📋 Help — All Commands Summary',
    description: [
      '**Quick Reference**',
      '`&help` — Show this help menu',
      '`&help <command>` — Get details on a specific command',
      '',
      '🔵 **Slash only:** welcome, ticket, embed, reactionrole, temprole, timer',
      '🟡 **Prefix & Slash:** giveaway (gs/ge/gr)',
      '🟠 **Prefix only:** moderation, info, invites, triggers, snipe, logs',
      '',
      '**Permissions:**',
      '`Admin` — antilink, antinuke, blacklist, disable/enable, logs, ireset all, triggers',
      '`Manage Roles` — reaction roles, addrole, removerole, temprole',
      '`Manage Messages` — mute, unmute, warn, purge, lock, unlock',
      '`Ban Members` — ban, unban',
    ].join('\n')
  }
];

const CMD_DETAILS = {
  gs: { usage: '`&gs <duration> <winners> <prize>`', example: '`&gs 1h 1 Discord Nitro`', desc: 'Start a giveaway. Duration: 10m, 1h, 1d etc.' },
  ge: { usage: '`&ge <id>`', example: '`&ge 3`', desc: 'End a giveaway early by its ID.' },
  gr: { usage: '`&gr <id>`', example: '`&gr 3`', desc: 'Reroll a giveaway winner.' },
  mute: { usage: '`&mute @user [duration] [reason]`', example: '`&mute @Spammer 10m Spamming`', desc: 'Timeout a user. Default 10 minutes.' },
  ban: { usage: '`&ban @user [reason]`', example: '`&ban @User Rule violation`', desc: 'Ban a user from the server.' },
  warn: { usage: '`&warn @user [reason]`', example: '`&warn @User Being rude`', desc: 'Issue a warning to a user.' },
  purge: { usage: '`&purge <amount>`', example: '`&purge 50`', desc: 'Delete up to 150 messages at once.' },
  trigger: { usage: '`&trigger add <word> <reply>`', example: '`&trigger add hello Hello there!`', desc: 'Add auto-reply trigger. Use `reaction` type for emoji reactions.' },
  antilink: { usage: '`&antilink enable/disable`', example: '`&antilink enable`', desc: 'Block links in chat. GIF links are always allowed.' },
};

export async function handleHelp(message, args, config, client) {
  const cmd = args[0]?.toLowerCase();
  if (cmd && CMD_DETAILS[cmd]) {
    const d = CMD_DETAILS[cmd];
    return message.reply({ embeds: [makeEmbed({
      title: `📖 Help: ${cmd}`,
      thumbnail: client.user.displayAvatarURL(),
      fields: [
        { name: 'Usage', value: d.usage },
        { name: 'Example', value: d.example },
        { name: 'Description', value: d.desc }
      ]
    })] });
  }

  let page = 0;
  function buildMsg(p) {
    const embed = makeEmbed({
      title: pages[p].title,
      description: pages[p].description,
      thumbnail: client.user.displayAvatarURL(),
      footer: { text: `Page ${p + 1}/${pages.length} • Prefix: ${config.prefix || '&'}` }
    });
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('help_prev').setLabel('◀').setStyle(ButtonStyle.Secondary).setDisabled(p === 0),
      new ButtonBuilder().setCustomId('help_next').setLabel('▶').setStyle(ButtonStyle.Secondary).setDisabled(p === pages.length - 1),
    );
    return { embeds: [embed], components: [row] };
  }

  const msg = await message.reply(buildMsg(0));
  const collector = msg.createMessageComponentCollector({ time: 120000 });
  collector.on('collect', async i => {
    if (i.user.id !== message.author.id) return i.reply({ content: 'Not your help menu!', ephemeral: true });
    if (i.customId === 'help_prev') page = Math.max(0, page - 1);
    if (i.customId === 'help_next') page = Math.min(pages.length - 1, page + 1);
    await i.update(buildMsg(page));
  });
  collector.on('end', () => msg.edit({ components: [] }).catch(() => {}));
}
